CREATE TABLE Branches (
    Branch_id INT PRIMARY KEY,
    Branch_name VARCHAR(255),
    Location VARCHAR(255),
    Contact VARCHAR(50),
    Email VARCHAR(255),
    Room_id INT NULL
);