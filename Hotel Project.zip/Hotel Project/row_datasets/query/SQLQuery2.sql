CREATE DATABASE HotelDatabase;
GO
USE HotelDatabase;
GO